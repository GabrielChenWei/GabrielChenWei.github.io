import pyautogui

# Move the mouse to the x, y coordinates 100, 150
pyautogui.moveTo(100, 150)