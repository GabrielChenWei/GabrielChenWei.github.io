import pystray
from PIL import Image, ImageDraw
import time

def create_image():
    width = 64
    height = 64
    image = Image.new('RGB', (width, height), (255, 255, 255))
    dc = ImageDraw.Draw(image)
    dc.rectangle((width // 2 - 10, height // 2 - 10, width // 2 + 10, height // 2 + 10), fill=(0, 0, 0))
    return image

def on_quit(icon, item):
    icon.stop()

def show_message(icon, item):
    print("Menu item clicked!")

icon = pystray.Icon("test_icon", create_image(), "Test Icon", menu=pystray.Menu(
    pystray.MenuItem("Show Message", show_message),
    pystray.MenuItem("Quit", on_quit)
))

icon.run()

# Keep the script running
while True:
    time.sleep(1)