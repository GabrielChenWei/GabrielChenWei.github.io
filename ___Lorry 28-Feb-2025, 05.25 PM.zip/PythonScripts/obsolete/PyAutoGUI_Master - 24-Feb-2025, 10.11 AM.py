import pyautogui
import keyboard
from pynput import mouse
from datetime import datetime, timedelta
import os
import sys
import pyperclip
import time
import pystray
from PIL import Image, ImageDraw
import ctypes

# Buffer to keep track of the last few keystrokes
key_buffer = []

##### [Windows] + [t] : show this tip #####
def show_tip():
    tip_message = (
        "Latest update : 21-Feb-2025, 08.24 AM\n\n"
        "* Right click Python script icon 🟩 to hide/show console or quit this script\n"
        "* [Windows] + [t] : show this tip\n"
        "* [Ctrl] + [ESC] : stop this script\n"
        "* [Ctrl] + [Shift] + [a] : reload this instance\n"
        "* ddd : current date in the format of \"03-Oct-2016\"\n"
        "* ttt : current time in the format of \"03-Oct-2016, 3.01 PM\"\n"
        "* tmr : tomorrow's date in the format of \"03-Oct-2016\"\n"
        "* yyy : yesterday's date in the format of \"03-Oct-2016\"\n"
        "* mmm : current month and year in the format of \"Oct-2016\"\n"
        "* [Windows] + [Alt] + [↑] : CONVERT SELECTED TEXT TO UPPERCASE\n"
        "* [Windows] + [Alt] + [↓] : convert selected text to lowercase\n"
        "* [Windows] + [Alt] + [→] : Convert Selected Text To Capitalized\n"
        "* [Windows] + [Alt] + [←] : iNVERT sELECTED tEXT cASE\n"
        "* Double click [Right button] : show desktop\n"
        "* ~ : ~~\t \" : \"\"\t ( : ()\t [ : []\t { : {}\t < : <>\n"
        "* [Windows] + [c] : copy selection to clipboard without format"
               
    )
    pyautogui.alert(tip_message)
##### [Windows] + [t] : show this tip #####

##### [Ctrl] + [Shift] + [a] : reload this instance #####
def reload_script():
    os.execv(sys.executable, ['python'] + sys.argv)
##### [Ctrl] + [Shift] + [a] : reload this instance #####

##### [Ctrl] + [ESC] : stop this script #####
# Add a hotkey to show the tip
keyboard.add_hotkey('win+t', show_tip)

# Add a hotkey to stop the script
keyboard.add_hotkey('ctrl+esc', lambda: keyboard.unhook_all())

# Add a hotkey to reload the script
keyboard.add_hotkey('ctrl+shift+a', reload_script)
##### [Ctrl] + [ESC] : stop this script #####

##### ddd : current date in the format of "03-Oct-2016" #####
def replace_ddd_with_date():  
    # Get the current date in the format dd-MMM-yyyy
    current_date = datetime.now().strftime('%d-%b-%Y')
    
    # Press backspace three times to remove "ddd"
    pyautogui.press('backspace', presses=3)
    
    # Type the current date
    pyautogui.write(current_date)
##### ddd : current date in the format of "03-Oct-2016" #####

##### ttt : current time in the format of "03-Oct-2016, 3.01 PM" #####
def replace_ttt_with_time(): 
    # Get the current time in the format dd-MMM-yyyy, h.mm AM/PM
    current_time = datetime.now().strftime('%d-%b-%Y, %I.%M %p')
    
    # Press backspace three times to remove "ttt"
    pyautogui.press('backspace', presses=3)
    
    # Type the current time
    pyautogui.write(current_time)
##### ttt : current time in the format of "03-Oct-2016, 3.01 PM" #####

##### tmr : tomorrow's date in the format of "03-Oct-2016" #####
def replace_tmr_with_tomorrow_date():
    # Get tomorrow's date in the format dd-MMM-yyyy
    tomorrow_date = (datetime.now() + timedelta(days=1)).strftime('%d-%b-%Y')
    
    # Press backspace three times to remove "tmr"
    pyautogui.press('backspace', presses=3)
    
    # Type tomorrow's date
    pyautogui.write(tomorrow_date)
##### tmr : tomorrow's date in the format of "03-Oct-2016" #####

##### yyy : yesterday's date in the format of "03-Oct-2016" #####
def replace_yyy_with_yesterday_date():
    yesterday_date = (datetime.now() - timedelta(days=1)).strftime('%d-%b-%Y')
    pyautogui.press('backspace', presses=3)
    pyautogui.write(yesterday_date)
##### yyy : yesterday's date in the format of "03-Oct-2016" #####

##### mmm : current month and year in the format of "Oct-2016" #####
def replace_mmm_with_month_year():
    month_year = datetime.now().strftime('%b-%Y')
    pyautogui.press('backspace', presses=3)
    pyautogui.write(month_year)
##### mmm : current month and year in the format of "Oct-2016" #####

##### [Windows] + [Alt] + [↑] : convert selected text to uppercase #####
def convert_selected_text_to_uppercase():
    # Clear the clipboard
    pyperclip.copy('')
    # Add a short delay before copying
    time.sleep(0.5)
    # Copy the selected text using the keyboard module
    keyboard.press_and_release('ctrl+c')
    # Add a short delay to ensure the clipboard is updated
    time.sleep(0.5)
    # Get the copied text from the clipboard
    selected_text = pyperclip.paste()
    # Convert the text to uppercase
    uppercase_text = selected_text.upper()
    # Replace the selected text with the uppercase text
    pyautogui.write(uppercase_text)
##### [Windows] + [Alt] + [↑] : convert selected text to uppercase #####

##### [Windows] + [Alt] + [↓] : convert selected text to lowercase #####
def convert_selected_text_to_lowercase():
    # Clear the clipboard
    pyperclip.copy('')
    # Add a short delay before copying
    time.sleep(0.5)
    # Copy the selected text using the keyboard module
    keyboard.press_and_release('ctrl+c')
    # Add a short delay to ensure the clipboard is updated
    time.sleep(0.5)
    # Get the copied text from the clipboard
    selected_text = pyperclip.paste()
    # Convert the text to lowercase
    lowercase_text = selected_text.lower()
    # Replace the selected text with the lowercase text
    pyautogui.write(lowercase_text)
##### [Windows] + [Alt] + [↓] : convert selected text to lowercase #####

##### [Windows] + [Alt] + [→] : convert selected text to capitalized #####
def convert_selected_text_to_capitalized():
    # Clear the clipboard
    pyperclip.copy('')
    # Add a short delay before copying
    time.sleep(0.5)
    # Copy the selected text using the keyboard module
    keyboard.press_and_release('ctrl+c')
    # Add a short delay to ensure the clipboard is updated
    time.sleep(0.5)
    # Get the copied text from the clipboard
    selected_text = pyperclip.paste()
    # Convert the text to capitalized
    capitalized_text = selected_text.title()
    # Replace the selected text with the capitalized text
    pyautogui.write(capitalized_text)
##### [Windows] + [Alt] + [→] : convert selected text to capitalized #####

##### [Windows] + [Alt] + [←] : invert selected text case #####
def invert_selected_text_case():
    # Clear the clipboard
    pyperclip.copy('')
    # Add a short delay before copying
    time.sleep(0.5)
    # Copy the selected text using the keyboard module
    keyboard.press_and_release('ctrl+c')
    # Add a short delay to ensure the clipboard is updated
    time.sleep(0.5)
    # Get the copied text from the clipboard
    selected_text = pyperclip.paste()
    # Invert the case of the text
    inverted_text = ''.join([char.lower() if char.isupper() else char.upper() for char in selected_text])
    # Replace the selected text with the inverted case text
    pyautogui.write(inverted_text)
##### [Windows] + [Alt] + [←] : invert selected text case #####

##### Double click [Right button] : show desktop #####
def on_click(x, y, button, pressed):
    if button == mouse.Button.right and not pressed:
        if on_click.last_click_time and time.time() - on_click.last_click_time < 0.3:
            pyautogui.hotkey('win', 'd')
        on_click.last_click_time = time.time()

on_click.last_click_time = None

# Start the mouse listener
listener = mouse.Listener(on_click=on_click)
listener.start()
##### Double click [Right button] : show desktop #####

##### [Windows] + [c] : copy selection to clipboard without format #####
def copy_selection_to_clipboard():
    pyperclip.copy(pyperclip.paste())
keyboard.add_hotkey('win+c', copy_selection_to_clipboard)
##### [Windows] + [c] : copy selection to clipboard without format #####

##### Handle key events and check for specific sequences #####
def on_key_event(event):  
    global key_buffer
    
    # Add the new key to the buffer
    key_buffer.append(event.name)
    
    # Keep only the last three keys in the buffer
    if len(key_buffer) > 3:
        key_buffer.pop(0)
    
    # Check if the last three keys are "d", "d", "d"
    if key_buffer == ['d', 'd', 'd']:
        replace_ddd_with_date()
        key_buffer = []  # Clear the buffer after replacement
    
    # Check if the last three keys are "t", "t", "t"
    if key_buffer == ['t', 't', 't']:
        replace_ttt_with_time()
        key_buffer = []  # Clear the buffer after replacement
    
    # Check if the last three keys are "t", "m", "r"
    if key_buffer == ['t', 'm', 'r']:
        replace_tmr_with_tomorrow_date()
        key_buffer = []  # Clear the buffer after replacement
    
    # Check if the last three keys are "y", "y", "y"    
    if key_buffer == ['y', 'y', 'y']:
        replace_yyy_with_yesterday_date()
        key_buffer = []
    
    # Check if the last three keys are "m", "m", "m" 
    if key_buffer == ['m', 'm', 'm']:
        replace_mmm_with_month_year()
        key_buffer = []
##### Handle key events and check for specific sequences #####

##### Hotkey list #####
# Hook the keyboard event
keyboard.on_press(on_key_event)

# Add a hotkey to convert selected text to uppercase
keyboard.add_hotkey('win+alt+up', convert_selected_text_to_uppercase)

# Add a hotkey to convert selected text to lowercase
keyboard.add_hotkey('win+alt+down', convert_selected_text_to_lowercase)

# Add a hotkey to convert selected text to capitalized
keyboard.add_hotkey('win+alt+right', convert_selected_text_to_capitalized)

# Add a hotkey to invert selected text case
keyboard.add_hotkey('win+alt+left', invert_selected_text_case)

# Add hotkeys for specific characters
keyboard.add_hotkey('shift+`', lambda: pyautogui.write('~') or pyautogui.press('left'))
keyboard.add_hotkey("shift+'", lambda: pyautogui.write('"') or pyautogui.press('left'))
keyboard.add_hotkey('shift+9', lambda: pyautogui.write(')') or pyautogui.press('left'))
keyboard.add_hotkey('[', lambda: pyautogui.write(']') or pyautogui.press('left'))
keyboard.add_hotkey('shift+[', lambda: pyautogui.write('}') or pyautogui.press('left'))
keyboard.add_hotkey('shift+<', lambda: pyautogui.write('>') or pyautogui.press('left'))
##### Hotkey list #####

##### Initialization #####
# Show the initial tip when the script is loaded
show_tip()

# Function to create an icon for the system tray
def create_image():
    # Generate an image and draw a pattern
    width = 64
    height = 64
    image = Image.new('RGB', (width, height), (152, 251, 152))
    dc = ImageDraw.Draw(image)
    dc.rectangle(
        (width // 2 - 10, height // 2 - 10, width // 2 + 10, height // 2 + 10),
        fill=(0, 0, 0))
    return image

# Function to quit the script from the system tray
def quit_action(icon, item):
    icon.stop()
    keyboard.unhook_all()
    sys.exit()

# Function to show the console window
def show_console():
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 1)

# Function to hide the console window
def hide_console():
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)

# Create the system tray icon
icon = pystray.Icon("test_icon", create_image(), "Python Script", menu=pystray.Menu(
    pystray.MenuItem("Show Console", lambda icon, item: show_console()),
    pystray.MenuItem("Hide Console", lambda icon, item: hide_console()),
    pystray.MenuItem("Quit", quit_action)
))

# Ensure the icon remains visible and responsive
icon.run_detached()

# Hide the console window
hide_console()

# Keep the script running
while True:
    time.sleep(1)

'''
# Keep the script running
keyboard.wait('esc')  # Press 'esc' to stop the script
'''
##### Initialization #####