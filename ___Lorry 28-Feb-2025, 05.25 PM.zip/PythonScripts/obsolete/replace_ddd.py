import pyautogui
import keyboard
from datetime import datetime

# Buffer to keep track of the last few keystrokes
key_buffer = []

def replace_ddd_with_date():
    # Get the current date in the format dd-MMM-yyyy
    current_date = datetime.now().strftime('%d-%b-%Y')
    
    # Press backspace three times to remove "ddd"
    pyautogui.press('backspace', presses=3)
    
    # Type the current date
    pyautogui.write(current_date)

def on_key_event(event):
    global key_buffer
    
    # Add the new key to the buffer
    key_buffer.append(event.name)
    
    # Keep only the last three keys in the buffer
    if len(key_buffer) > 3:
        key_buffer.pop(0)
    
    # Check if the last three keys are "d", "d", "d"
    if key_buffer == ['d', 'd', 'd']:
        replace_ddd_with_date()
        key_buffer = []  # Clear the buffer after replacement

# Hook the keyboard event
keyboard.on_press(on_key_event)

# Keep the script running
keyboard.wait('esc')  # Press 'esc' to stop the script