import mouse

def on_right_click():
    print("Right button clicked")

mouse.on_right_click(on_right_click)

print("Listening for right mouse button clicks...")
mouse.wait('right')