import ctypes
import time

def hide_console():
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)

def show_console():
    ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 1)

# Hide the console window
hide_console()

# Keep the script running for 10 seconds to observe the behavior
time.sleep(10)

# Show the console window again
show_console()